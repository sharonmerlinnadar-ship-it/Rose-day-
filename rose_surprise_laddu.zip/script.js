
function showSurprise() {
  document.querySelector('.card').style.display = 'none';
  document.getElementById('surprise').style.display = 'block';
}
